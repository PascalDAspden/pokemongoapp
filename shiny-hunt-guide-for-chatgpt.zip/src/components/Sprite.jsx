import { useEffect, useState } from 'react';
import {
  safeUrl,
  normalizedSpriteUrl,
  shinySource,
} from '../utils/pokemonForms.js';

/**
 * Renders a Pokémon's artwork.
 *
 * - shiny=true keeps the Pokémon shiny (used by your existing shiny toggle).
 * - Desktop hover temporarily previews the shiny.
 * - Mobile users can tap the ✨ button to preview the shiny.
 * - Falls back to normal art if shiny art fails.
 * - Falls back to ✦ if normal art also fails.
 */
export default function Sprite({
  src,
  name,
  shiny = false,
  shinyFormArt = {},
  size = 64,
}) {
  const [stage, setStage] = useState('shiny');
  const [hoverShiny, setHoverShiny] = useState(false);
  const [tapShiny, setTapShiny] = useState(false);

  // Reset image fallback state when a different Pokémon is rendered.
  useEffect(() => {
    setStage('shiny');
    setHoverShiny(false);
    setTapShiny(false);
  }, [src, name]);

  const normalized = normalizedSpriteUrl(src);
  const normalUrl = safeUrl(normalized) || safeUrl(src);

  // Always calculate the shiny URL so it is available for hover/tap preview,
  // even when the main shiny toggle is currently off.
  const shinyUrl = safeUrl(
    shinySource(name, normalized, shinyFormArt)
  );

  const shadow = /^shadow\s/i.test(String(name || ''));

  // Existing shiny toggle wins.
  // Otherwise hover/tap can temporarily preview the shiny.
  const wantsShiny = shiny || hoverShiny || tapShiny;

  const showShiny =
    wantsShiny &&
    Boolean(shinyUrl) &&
    stage === 'shiny';

  // If both shiny and normal artwork have failed, show the fallback.
  const url =
    stage === 'fallback'
      ? ''
      : showShiny
        ? shinyUrl
        : normalUrl;

  const handleImageError = () => {
    setStage((currentStage) => {
      // Shiny failed -> try normal.
      if (showShiny && currentStage === 'shiny') {
        return 'normal';
      }

      // Normal failed -> fallback symbol.
      return 'fallback';
    });
  };

  const toggleMobilePreview = (event) => {
    // Prevent tapping the sparkle from also opening the Pokémon/card.
    event.stopPropagation();

    setTapShiny((current) => !current);
  };

  return (
    <div
      className={`sprite-box${shadow ? ' shadow-aura' : ''}`}
      style={{ width: size, height: size }}
      onMouseEnter={() => {
        if (!shiny && shinyUrl) {
          setHoverShiny(true);
        }
      }}
      onMouseLeave={() => {
        setHoverShiny(false);
      }}
    >
      {url ? (
        <img
          className={showShiny ? 'shiny-art' : ''}
          src={url}
          alt={showShiny ? `Shiny ${name}` : name}
          loading="lazy"
          onError={handleImageError}
        />
      ) : (
        <span className="fallback">✦</span>
      )}

      {shinyUrl && !shiny && (
        <button
          type="button"
          className="shiny-preview-button"
          onClick={toggleMobilePreview}
          aria-label={
            tapShiny
              ? `Show normal ${name}`
              : `Preview shiny ${name}`
          }
          aria-pressed={tapShiny}
        >
          ✨
        </button>
      )}
    </div>
  );
}